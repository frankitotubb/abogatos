<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class CategoriaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categorias = DB::table('categorias')->where('disabled', 0)->orderBy('id', 'asc')->get();
        return view('categorias.index', compact('categorias'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $formulas = DB::table('formulas')->where('disabled', 0)->get();
        return view('categorias.create', compact('formulas'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $categoria = new Categoria($request->all());
        if ($categoria->save()) {
            Session::put('success', 'Categoria registrada correctamente.');
        } else {
            Session::put('danger', 'Error al registrar la categoria.');
        }
        return redirect()->route('categorias.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $categoria = Categoria::find($id);
        return view('categorias.show', compact('categoria'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $categoria = Categoria::find($id);
        return view('categorias.edit', compact('categoria'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $categoria = Categoria::find($id);
        $categoria->nombre = $request->nombre;
        $categoria->descripcion = $request->descripcion;
        $categoria->id_inventario = $request->id_inventario;
        $categoria->timestamps = false;
        if ($categoria->save()) {
            Session::put('success', 'Categoria modificado correctamente.');
        } else {
            Session::put('danger', 'Error al modificar la categoria.');
        }
        return redirect()->route('formulas.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $inventario = Categoria::findOrFail($id);
        $inventario->disabled = 1;
        if ($inventario->save()) {
            Session::put('success', 'Inventario eliminada correctamente.');
        } else {
            Session::put('danger', 'Error al eliminar un inventario.');
        }
        return redirect()->route('formulas.index');
    }
}
