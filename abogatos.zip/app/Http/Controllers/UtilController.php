<?php

namespace App\Http\Controllers;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UtilController extends Controller
{
    public function updateestilo(Request $request)
    {
        try {
            $estilo = $request->input('estilo');
            $id = Auth::user()->id;
            $courier = User::findOrFail($id);
            $courier->estilo = $estilo;

            $courier->save();
            $request->session()->put('sidebar', $estilo);
            $request->session()->put('background', $estilo);
        } catch (\Exception $e) {
            return response($e->getMessage(), 400);
        }
        return response('ok estilo', 200);
    }

    public function updatemodo(Request $request)
    {
        try {
            $modo = $request->input('modo');
            $id = Auth::user()->id;
            $courier = User::findOrFail($id);
            $courier->modo = $modo;

            $courier->save();
            $request->session()->put('modo', $modo);
        } catch (\Exception $e) {
            return response($e->getMessage(), 400);
        }
        return response('ok modo', 200);
    }

    public function updatefuente(Request $request)
    {
        try {
            $fuente = $request->input('fuente');
            $id = Auth::user()->id;
            $courier = User::findOrFail($id);
            $courier->fuente = $fuente;

            $courier->save();
            $request->session()->put('fuente', $fuente);
        } catch (\Exception $e) {
            return response($e->getMessage(), 400);
        }
        return response('ok fuente', 200);
    }

    public function compareHora() {
        $tiempo = Carbon::now();
        echo $tiempo->toTimeString();
    }
}
