<?php

use App\Http\Controllers\CasoController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\EventoController;
use App\Http\Controllers\FormulaController;
use App\Http\Controllers\InventarioController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SeguimientoController;
use App\Http\Controllers\TareaController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\UtilController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::resource('tareas', TareaController::class);
    Route::resource('inventarios', InventarioController::class);
    Route::resource('formulas', FormulaController::class);
    Route::resource('categorias', CategoriaController::class);
    Route::resource('casos', CasoController::class);
    Route::resource('seguimientos', SeguimientoController::class);
    Route::resource('eventos', EventoController::class);
    Route::resource('usuarios', UsuarioController::class);
});

require __DIR__.'/auth.php';


Route::get('/casos', function () {
    return view('casos.index');
})->name('casos.index');

Route::get('phpmyinfo', function () {
    phpinfo(); 
})->name('phpmyinfo');

Route::post('/updateestilo', [UtilController::class, 'updateestilo'])->name('updateestilo');
Route::post('/updatemodo', [UtilController::class, 'updatemodo'])->name('updatemodo');
Route::post('/updatefuente', [UtilController::class, 'updatefuente'])->name('updatefuente');
Route::get('/comparehora', [UtilController::class, 'compareHora'])->name('comparehora');
