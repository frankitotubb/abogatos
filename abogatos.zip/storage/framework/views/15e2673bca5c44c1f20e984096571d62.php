<?php $__currentLoopData = ['info','success','warning','danger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has($type)): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-<?php echo e($type); ?> alert-dismissible fade show" style="border: none">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><i class="fa fa-times fa-sm"></i></button>
                    
                    <span class="text-xs font-weight-bolder"><?php echo Session::get($type); ?></span>
                </div>
            </div>
        </div>
        <?php echo e(Session::forget($type)); ?>

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Proyectos 2023\abogados\abogatos\resources\views/partials/alert.blade.php ENDPATH**/ ?>