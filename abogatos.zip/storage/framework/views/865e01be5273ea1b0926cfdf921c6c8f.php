<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h5>Gestión de Inventarios</h5>
                    <div class="d-flex align-items-center">
                        <span class="text-sm">Tabla con datos de los inventarios registrados.</span>
                        <a class="btn btn-success ms-auto" type="button" href="<?php echo e(route('inventarios.create')); ?>"><i
                                class="fa fa-plus"></i> Registrar Inventario</a>
                    </div>
                </div>
                <div class="card-body px-0 pt-2 pb-2">
                    <?php if(count($inventarios) == 0): ?>
                        <div class="d-flex align-items-center justify-content-center p-2">
                            <span class="text-sm">No existen inventarios registrados hasta el momento.</span>
                            <br>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xs font-weight-bolder">
                                            ID</th>
                                        <th class="text-uppercase text-secondary text-xs font-weight-bolder ps-2">
                                            Nombre</th>
                                        <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">
                                            Ubicación</th>
                                        <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">
                                            Capacidad</th>
                                        <th class="text-secondary"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $inventarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex px-3 py-1">
                                                    <div class="d-flex flex-column justify-content-center">
                                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($inventario->id); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <p class="text-xs font-weight-bold mb-0"><?php echo e($inventario->nombre); ?></p>
                                            </td>
                                            <td class="align-middle text-center text-sm">
                                                <span
                                                    class="badge badge-sm bg-gradient-success"><?php echo e($inventario->ubicacion); ?></span>
                                            </td>
                                            <td class="align-middle text-center text-sm">
                                                <span
                                                    class="badge badge-sm bg-gradient-warning"><?php echo e($inventario->capacidad); ?></span>
                                            </td>

                                            <td class="align-middle text-center text-sm">
                                                <a href="<?php echo e(route('inventarios.edit', [$inventario->id])); ?>"
                                                    class="btn btn-info btn-xs text-white" data-toggle="tooltip"
                                                    data-original-title="Edit user">
                                                    Editar
                                                </a>

                                                <form action="<?php echo e(route('inventarios.destroy', [$inventario->id])); ?>"
                                                    method="post" style="display: inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-xs"
                                                        onClick="return confirm('Está seguro de eliminar?')">
                                                        <i class="fas fa-trash-alt"></i> Eliminar
                                                    </button>
                                                </form>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos 2023\abogados\abogatos\resources\views/inventarios/index.blade.php ENDPATH**/ ?>