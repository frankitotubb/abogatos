<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h5>Gestión de Usuarios</h5>
                    <div class="d-flex align-items-center">
                        <span class="text-sm">Tabla con datos de los usuarios registrados.</span>
                        <a class="btn btn-success ms-auto disabled" type="button" href="<?php echo e(route('usuarios.create')); ?>"><i
                                class="fa fa-plus"></i> Crear</a>
                    </div>
                </div>
                <div class="card-body px-0 pt-2 pb-2">
                    <?php if(count($users) == 0): ?>
                        <div class="d-flex align-items-center justify-content-center p-2">
                            <span class="text-sm">No existen usuarios registrados hasta el momento.</span>
                            <br>
                        </div>
                    <?php else: ?>
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xs font-weight-bolder">
                                        ID</th>
                                    <th class="text-uppercase text-secondary text-xs font-weight-bolder ps-2">
                                        Nombre</th>
                                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">
                                        Correo</th>
                                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">
                                        Contraseña</th>
                                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder">
                                        Rol</th>
                                    <th class="text-secondary"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex px-3 py-1">
                                                <div class="d-flex flex-column justify-content-center">
                                                    <p class="text-xs font-weight-bold mb-0"><?php echo e($user->id); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="text-xs font-weight-bold mb-0"><?php echo e($user->name); ?></p>
                                        </td>
                                        <td class="align-middle text-center text-sm">
                                            <span
                                                class="badge badge-sm bg-gradient-success"><?php echo e($user->email); ?></span>
                                        </td>
                                        <td class="align-middle text-center text-sm">
                                            <span class="badge badge-sm bg-gradient-success">************************</span>
                                        </td>
                                        <td class="align-middle text-center text-sm">   
                                            <span
                                                class="badge badge-sm bg-gradient-warning"><?php echo e($user->rol); ?></span>
                                        </td>
                                        
                                        <td class="align-middle text-center text-sm">
                                            <a href="<?php echo e(route('usuarios.edit', [$user->id])); ?>"
                                                class="btn btn-info btn-xs text-white" data-toggle="tooltip"
                                                data-original-title="Edit user">
                                                Editar
                                            </a>
                                            
                                            <form action="<?php echo e(route('usuarios.destroy', [$user->id])); ?>" method="post"
                                                style="display: inline">
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('DELETE'); ?>
                                              <button type="submit" class="btn btn-danger btn-xs"
                                                      onClick="return confirm('Está seguro de eliminar?')">
                                                  <i class="fas fa-trash-alt"></i> Eliminar
                                              </button>
                                          </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Proyectos 2023\abogados\abogatos\resources\views/usuarios/index.blade.php ENDPATH**/ ?>